# HideFileInMusic
用wav格式的歌曲隐藏任意文件，小说、图片、种子等。

那个wav文件，有点大，你可以用自己机子上的任何.wav文件来代替（小白请选择大小在5M以上的文件，否则可能溢出）


关于这个程序的视频教程：https://www.bilibili.com/video/BV1NF411i7Zh/
作者：B站@偶尔有点小迷糊
我的口号是：用不正经的风格 讲正经编程知识


